//
//  GroceriesViewController.swift
//  Arigela_Groceries
//
//  Created by Arigela,Rajesh on 4/17/24.
//

import UIKit

class GroceriesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fType.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let rCell = itemCollectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as! ItemCollectionViewCell
        let currItem = fType[indexPath.row]
        rCell.imgDisplay(with: currItem)
        return rCell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        displayDetails(index: indexPath)
    }
    
    func displayDetails(index: IndexPath){
        itemNameLabel.text = "Product Name: \(fType[(index.row)].itemName)"
        itemPriceLabel.text = "Price: $\(String(fType[(index.row)].itemPrice))"
        itemExpireLabel.text = "Expires on :\(fType[(index.row)].itemExpiry)"
        itemDescriptionLabel.text = "Description: \(fType[(index.row)].itemDescription)"
        itemQuantityLabel.text = "Qunatity: \(String(fType[(index.row)].itemQuantity))"
        itemOriginLabel.text = "Origin: \(fType[(index.row)].itemOrigin)"
    }
   
    
    @IBOutlet weak var itemCollectionView: UICollectionView!
    
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    @IBOutlet weak var itemExpireLabel: UILabel!
    
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    
    @IBOutlet weak var itemQuantityLabel: UILabel!
    
    @IBOutlet weak var itemOriginLabel: UILabel!
    
    var fType : [Item] = []
    var ttlName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        itemNameLabel.text = "Product Name: \(fType[0].itemName)"
        itemPriceLabel.text = "Price: $\(String(fType[0].itemPrice))"
        itemExpireLabel.text = "Expires on: \(fType[0].itemExpiry)"
        itemDescriptionLabel.text = "Description: \(fType[0].itemDescription)"
        itemQuantityLabel.text = "Qunatity: \(String(fType[0].itemQuantity))"
        itemOriginLabel.text = "Origin: \(fType[0].itemOrigin)"
        itemCollectionView.delegate = self
        itemCollectionView.dataSource = self
        self.title = ttlName
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
