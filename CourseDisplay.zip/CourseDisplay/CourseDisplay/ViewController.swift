//
//  ViewController.swift
//  CourseDisplay
//
//  Created by Arigela,Rajesh on 2/22/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var crsNumOL: UILabel!
    
    @IBOutlet weak var crsTitleOL: UILabel!
    
    @IBOutlet weak var semesterOL: UILabel!
    
    @IBOutlet weak var previousOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    //populate an array
    let courses = [["img01","44555","Network Security","fall"],["img02","44665","iOS","spring"],["img03","44565","Data Streaming","summer"]]
    
    var imgNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Previous btn should be displayed
        previousOL.isEnabled = false;
        
        //Display the first course details(index 0)
        updateContents(0)
    }

    @IBAction func prevBtnClicked(_ sender: Any) {
        
        //next btn should be enabled.
        nextOL.isEnabled=true;
        
        //decrement the img num
        imgNum=imgNum-1
        
        //update the contents
        updateContents(imgNum)
        
        //once you reach the begining of the array, the prev btn should be disabled
        if(imgNum==0) {
            previousOL.isEnabled=false;
        }
        
    }
    
    @IBAction func nextBtnClicked(_ sender: Any) {
        
        //Prev btn should be enabled
        previousOL.isEnabled = true;
        
        //Increment the img num
        imgNum = imgNum+1
        
        //updating the course details
        updateContents(imgNum)
        
        //once the user reach the end of the array, next btn should disabled
        if(imgNum==courses.count-1){
            nextOL.isEnabled=false;
        }
    }//end of the next btn
    
    //Below is the helper function to update the contents
    func updateContents(_ imgNumber:Int) {
        imageOL.image=UIImage(named: courses[imgNumber][0])
        crsNumOL.text=courses[imgNumber][1]
        crsTitleOL.text=courses[imgNumber][2]
        semesterOL.text=courses[imgNumber][3]
    }
    
}

