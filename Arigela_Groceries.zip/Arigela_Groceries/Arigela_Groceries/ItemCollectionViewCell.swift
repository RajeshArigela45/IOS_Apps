//
//  ItemCollectionViewCell.swift
//  Arigela_Groceries
//
//  Created by Arigela,Rajesh on 4/17/24.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    
    
}
