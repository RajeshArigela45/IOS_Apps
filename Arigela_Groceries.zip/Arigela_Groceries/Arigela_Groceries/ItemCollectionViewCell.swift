//
//  ItemCollectionViewCell.swift
//  Arigela_Groceries
//
//  Created by Arigela,Rajesh on 4/17/24.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imgDisplayOL: UIImageView!
    
    func imgDisplay(with u:Item){
        imgDisplayOL.image = u.image
    }
    
}
