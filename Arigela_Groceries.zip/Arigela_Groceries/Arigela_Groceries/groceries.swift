//
//  groceries.swift
//  Arigela_Groceries
//
//  Created by Arigela,Rajesh on 4/17/24.
//

import Foundation
import UIKit
struct Item{
    let itemName: String
    let image: UIImage
    let itemPrice: Double
    let itemExpiry: String
    let itemDescription: String
    let itemQuantity: Int
    let itemOrigin: String
}



// Generate Data
let fruits: [Item] = [
    Item(itemName: "Apple", image: UIImage(named: "apple")!, itemPrice: 0.99, itemExpiry: "2024-05-15", itemDescription: "Fresh, crisp, and juicy apples", itemQuantity: 20, itemOrigin: "Washington"),
    Item(itemName: "Banana", image: UIImage(named: "banana")!, itemPrice: 0.59, itemExpiry: "2024-04-20", itemDescription: "Ripe and sweet bananas", itemQuantity: 15, itemOrigin: "Ecuador"),
    Item(itemName: "Orange", image: UIImage(named: "orange")!, itemPrice: 1.29, itemExpiry: "2024-06-01", itemDescription: "Juicy and vitamin-packed oranges", itemQuantity: 10, itemOrigin: "Florida"),
    Item(itemName: "Strawberry", image: UIImage(named: "strawberry")!, itemPrice: 2.99, itemExpiry: "2024-04-25", itemDescription: "Freshly picked, sweet strawberries", itemQuantity: 8, itemOrigin: "California"),
    Item(itemName: "Blueberry", image: UIImage(named: "blueberry")!, itemPrice: 3.49, itemExpiry: "2024-05-01", itemDescription: "Plump and juicy blueberries", itemQuantity: 12, itemOrigin: "Oregon"),
    Item(itemName: "Mango", image: UIImage(named: "mango")!, itemPrice: 2.79, itemExpiry: "2024-06-10", itemDescription: "Ripe and flavorful mangoes", itemQuantity: 6, itemOrigin: "Mexico"),
    Item(itemName: "Pineapple", image: UIImage(named: "pineapple")!, itemPrice: 3.99, itemExpiry: "2024-05-20", itemDescription: "Sweet and tropical pineapples", itemQuantity: 4, itemOrigin: "Costa Rica"),
    Item(itemName: "Kiwi", image: UIImage(named: "kiwi")!, itemPrice: 1.79, itemExpiry: "2024-04-30", itemDescription: "Tangy and nutrient-rich kiwis", itemQuantity: 10, itemOrigin: "New Zealand"),
    Item(itemName: "Grape", image: UIImage(named: "grape")!, itemPrice: 2.49, itemExpiry: "2024-05-10", itemDescription: "Juicy and flavorful grapes", itemQuantity: 18, itemOrigin: "California"),
    Item(itemName: "Watermelon", image: UIImage(named: "watermelon")!, itemPrice: 4.99, itemExpiry: "2024-06-15", itemDescription: "Refreshing and sweet watermelons", itemQuantity: 2, itemOrigin: "Texas")
]

let vegetables: [Item] = [
    Item(itemName: "Carrot", image: UIImage(named: "carrot")!, itemPrice: 2.99, itemExpiry: "2024-05-20", itemDescription: "Fresh, crunchy carrots", itemQuantity: 20, itemOrigin: "California"),
    Item(itemName: "Broccoli", image: UIImage(named: "broccoli")!, itemPrice: 3.49, itemExpiry: "2024-04-30", itemDescription: "Nutrient-rich broccoli florets", itemQuantity: 12, itemOrigin: "Washington"),
    Item(itemName: "Tomato", image: UIImage(named: "tomato")!, itemPrice: 2.79, itemExpiry: "2024-06-01", itemDescription: "Juicy and flavorful tomatoes", itemQuantity: 18, itemOrigin: "Florida"),
    Item(itemName: "Potato", image: UIImage(named: "potato")!, itemPrice: 1.99, itemExpiry: "2024-05-15", itemDescription: "Versatile and starchy potatoes", itemQuantity: 25, itemOrigin: "Idaho"),
    Item(itemName: "Spinach", image: UIImage(named: "spinach")!, itemPrice: 2.49, itemExpiry: "2024-04-25", itemDescription: "Fresh and nutrient-dense spinach", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Onion", image: UIImage(named: "onion")!, itemPrice: 1.79, itemExpiry: "2024-06-10", itemDescription: "Aromatic and flavorful onions", itemQuantity: 15, itemOrigin: "Texas"),
    Item(itemName: "Zucchini", image: UIImage(named: "zucchini")!, itemPrice: 2.99, itemExpiry: "2024-05-01", itemDescription: "Tender and versatile zucchini", itemQuantity: 8, itemOrigin: "California"),
    Item(itemName: "Bell Pepper", image: UIImage(named: "bellpepper")!, itemPrice: 3.29, itemExpiry: "2024-05-10", itemDescription: "Crunchy and colorful bell peppers", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Cucumber", image: UIImage(named: "cucumber")!, itemPrice: 1.99, itemExpiry: "2024-04-30", itemDescription: "Fresh and hydrating cucumbers", itemQuantity: 16, itemOrigin: "Michigan"),
    Item(itemName: "Eggplant", image: UIImage(named: "eggplant")!, itemPrice: 2.79, itemExpiry: "2024-06-15", itemDescription: "Firm and flavorful eggplants", itemQuantity: 10, itemOrigin: "California")
]

let dairy: [Item] = [
    Item(itemName: "Milk", image: UIImage(named: "milk")!, itemPrice: 3.99, itemExpiry: "2024-05-01", itemDescription: "Whole, fresh milk", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Yogurt", image: UIImage(named: "yogurt")!, itemPrice: 1.99, itemExpiry: "2024-04-20", itemDescription: "Plain, low-fat yogurt", itemQuantity: 18, itemOrigin: "California"),
    Item(itemName: "Cheese", image: UIImage(named: "cheese")!, itemPrice: 4.79, itemExpiry: "2024-06-01", itemDescription: "Cheddar cheese block", itemQuantity: 8, itemOrigin: "Wisconsin"),
    Item(itemName: "Butter", image: UIImage(named: "butter")!, itemPrice: 3.29, itemExpiry: "2024-05-15", itemDescription: "Unsalted butter sticks", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Cream", image: UIImage(named: "cream")!, itemPrice: 2.99, itemExpiry: "2024-04-25", itemDescription: "Heavy whipping cream", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Sour Cream", image: UIImage(named: "sourcream")!, itemPrice: 2.49, itemExpiry: "2024-05-10", itemDescription: "Full-fat sour cream", itemQuantity: 14, itemOrigin: "California"),
    Item(itemName: "Cottage Cheese", image: UIImage(named: "cottagecheese")!, itemPrice: 2.79, itemExpiry: "2024-04-30", itemDescription: "Low-fat cottage cheese", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Eggs", image: UIImage(named: "eggs")!, itemPrice: 3.99, itemExpiry: "2024-05-20", itemDescription: "Large, grade A eggs", itemQuantity: 24, itemOrigin: "California"),
    Item(itemName: "Ice Cream", image: UIImage(named: "icecream")!, itemPrice: 4.99, itemExpiry: "2024-06-10", itemDescription: "Vanilla ice cream", itemQuantity: 1, itemOrigin: "California"),
    Item(itemName: "Ricotta", image: UIImage(named: "ricotta")!, itemPrice: 3.49, itemExpiry: "2024-05-01", itemDescription: "Whole milk ricotta cheese", itemQuantity: 15, itemOrigin: "California")
]

let grains: [Item] = [
    Item(itemName: "Bread", image: UIImage(named: "bread")!, itemPrice: 3.99, itemExpiry: "2024-04-20", itemDescription: "Whole wheat bread loaf", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Rice", image: UIImage(named: "rice")!, itemPrice: 2.49, itemExpiry: "2024-06-01", itemDescription: "Long grain white rice", itemQuantity: 20, itemOrigin: "California"),
    Item(itemName: "Pasta", image: UIImage(named: "pasta")!, itemPrice: 2.99, itemExpiry: "2024-05-15", itemDescription: "Whole wheat spaghetti", itemQuantity: 16, itemOrigin: "California"),
    Item(itemName: "Oats", image: UIImage(named: "oats")!, itemPrice: 3.29, itemExpiry: "2024-04-25", itemDescription: "Old-fashioned rolled oats", itemQuantity: 18, itemOrigin: "California"),
    Item(itemName: "Quinoa", image: UIImage(named: "quinoa")!, itemPrice: 4.49, itemExpiry: "2024-05-10", itemDescription: "Organic quinoa", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Cereal", image: UIImage(named: "cereal")!, itemPrice: 3.99, itemExpiry: "2024-04-30", itemDescription: "Whole grain cereal", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Flour", image: UIImage(named: "flour")!, itemPrice: 2.79, itemExpiry: "2024-06-10", itemDescription: "All-purpose flour", itemQuantity: 15, itemOrigin: "California"),
    Item(itemName: "Tortillas", image: UIImage(named: "tortillas")!, itemPrice: 3.49, itemExpiry: "2024-05-01", itemDescription: "Whole wheat tortillas", itemQuantity: 20, itemOrigin: "California"),
    Item(itemName: "Crackers", image: UIImage(named: "crackers")!, itemPrice: 2.99, itemExpiry: "2024-04-25", itemDescription: "Whole grain crackers", itemQuantity: 18, itemOrigin: "California"),
    Item(itemName: "Barley", image: UIImage(named: "barley")!, itemPrice: 3.29, itemExpiry: "2024-05-20", itemDescription: "Pearl barley", itemQuantity: 14, itemOrigin: "California")
]

let meats: [Item] = [
    Item(itemName: "Chicken", image: UIImage(named: "chicken")!, itemPrice: 4.99, itemExpiry: "2024-05-01", itemDescription: "Boneless, skinless chicken breasts", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Beef", image: UIImage(named: "beef")!, itemPrice: 6.99, itemExpiry: "2024-04-30", itemDescription: "Ground beef (93% lean)", itemQuantity: 8, itemOrigin: "California"),
    Item(itemName: "Pork", image: UIImage(named: "pork")!, itemPrice: 5.49, itemExpiry: "2024-06-01", itemDescription: "Pork chops", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Turkey", image: UIImage(named: "turkey")!, itemPrice: 5.99, itemExpiry: "2024-05-15", itemDescription: "Ground turkey (93% lean)", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Salmon", image: UIImage(named: "salmon")!, itemPrice: 8.99, itemExpiry: "2024-04-25", itemDescription: "Fresh salmon fillets", itemQuantity: 6, itemOrigin: "California"),
    Item(itemName: "Shrimp", image: UIImage(named: "shrimp")!, itemPrice: 9.99, itemExpiry: "2024-05-10", itemDescription: "Peeled and deveined shrimp", itemQuantity: 8, itemOrigin: "California"),
    Item(itemName: "Lamb", image: UIImage(named: "lamb")!, itemPrice: 7.99, itemExpiry: "2024-06-10", itemDescription: "Lamb chops", itemQuantity: 8, itemOrigin: "California"),
    Item(itemName: "Tuna", image: UIImage(named: "tuna")!, itemPrice: 4.99, itemExpiry: "2024-05-01", itemDescription: "Canned tuna in water", itemQuantity: 12, itemOrigin: "California"),
    Item(itemName: "Bacon", image: UIImage(named: "bacon")!, itemPrice: 5.49, itemExpiry: "2024-04-20", itemDescription: "Thick-cut bacon", itemQuantity: 10, itemOrigin: "California"),
    Item(itemName: "Ham", image: UIImage(named: "ham")!, itemPrice: 6.99, itemExpiry: "2024-05-15", itemDescription: "Sliced ham", itemQuantity: 8, itemOrigin: "California")
]

// Array to store categories along with their respective item lists to retrieve data in collection view.
let allCategories: [[Item]] = [fruits,vegetables,dairy,grains,meats]


// Array to store all category names to display in the table view and as title in the second view.
let categoryNames: [String] = ["Fruits","Vegetables","Dairy","Grains","Meats"]
