//
//  Contacts.swift
//  Singamala_PracticeExam03
//
//  Created by Uday on 4/16/24.
//

import Foundation

struct Contact {
    var firstName = ""
    var lastName = ""
    var phoneNumber = ""
    
    var initials: String {
            let firstInitial = firstName.prefix(1)
            let lastInitial = lastName.prefix(1)
            return "\(firstInitial) . \(lastInitial) . "
        }
}


let contacts: [Contact] = [
    Contact(firstName: "John", lastName: "Doe", phoneNumber: "123-456-7890"),
    Contact(firstName: "Jane", lastName: "Smith", phoneNumber: "456-789-0123"),
    Contact(firstName: "Michael", lastName: "Johnson", phoneNumber: "789-012-3456"),
    Contact(firstName: "Emily", lastName: "Brown", phoneNumber: "012-345-6789"),
    Contact(firstName: "William", lastName: "Taylor", phoneNumber: "345-678-9012"),
    Contact(firstName: "Olivia", lastName: "Anderson", phoneNumber: "678-901-2345"),
    Contact(firstName: "James", lastName: "Martinez", phoneNumber: "901-234-5678"),
    Contact(firstName: "Sophia", lastName: "Hernandez", phoneNumber: "234-567-8901"),
    Contact(firstName: "Alexander", lastName: "Young", phoneNumber: "567-890-1234"),
    Contact(firstName: "Emma", lastName: "Lee", phoneNumber: "890-123-4567")
]
