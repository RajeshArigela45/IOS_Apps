//
//  ViewController.swift
//  WordGuess
//
//  Created by Arigela,Rajesh on 3/7/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!

    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var words = [["java","java","Programming language"],["cat","cat","Animal"],["bike","bike","Two Wheeler"],["imac","imac","Apple Device"],["pen","pen","Used for exam"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
    }
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        
    }
    
    
}

