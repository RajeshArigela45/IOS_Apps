//
//  ViewController.swift
//  WordGuessApp
//
//  Created by Arigela,Rajesh on 2/27/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var displayLabelOL: UILabel!
    
    @IBOutlet weak var hintLabelOL: UILabel!
    
    @IBOutlet weak var textOL: UITextField!
    
    @IBOutlet weak var checkOL: UIButton!
    
    @IBOutlet weak var statusLabelOL: UILabel!
    
    @IBOutlet weak var playAgainOL: UIButton!
    
    var words = [["JAVA","Programming language"],["CAT","Animal"],["Bike","Two Wheeler"],["IMAC","Apple Device"]]
    
    var cnt=0;
    var word=""
    var ltrsGuessed=""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //check button should be disabled
        checkOL.isEnabled=false;
        
        //Get the first word from the array
        word=words[cnt][0]
        
        displayLabelOL.text=""
        
        //Populate the display label with the underscores. The # of underscores is equal to the # of characters in the word.
        updateUnderscores();
        
        //Get the first hint from the array
        hintLabelOL.text="Hint: "+words[cnt][1]
        
        //clear the status label
        statusLabelOL.text=""
    }

    @IBAction func textChange(_ sender: Any) {
        //Reading the input from the user
        var txtInp = textOL.text!
        //Consider only the last character by calling textEntered.last and trimming the white spaces.
        txtInp = String(txtInp.last ?? " ").trimmingCharacters(in: .whitespaces)
        textOL.text=txtInp
        
        //check whether the entered text is empty or not to enable check butn
        if txtInp.isEmpty {
            checkOL.isEnabled=true;
        }
        else {
            checkOL.isEnabled=false;
        }
    }
    
    @IBAction func checkBtnClicked(_ sender: Any) {
        
        
    }
    
    
    @IBAction func playAgainBtnClicked(_ sender: Any) {
        
    }
    
    func updateUnderscores() {
        for letter in word{
            displayLabelOL.text! += "_"
        }
    }
    
}

