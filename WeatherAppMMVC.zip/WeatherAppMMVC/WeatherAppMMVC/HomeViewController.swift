//
//  ViewController.swift
//  WeatherAppMMVC
//
//  Created by Arigela,Rajesh on 3/21/24.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var tempOL: UITextField!
    
    var result = ""
    var image = ""
    var temp:Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func checkWeatherBtn(_ sender: Any) {
        //Read Temperature value and assign it to a variable. Also convert it to double.
        temp = Double(tempOL.text!)!
        
        //check whether temp is hot or cold
        if(temp<60) {
            result = "It is cold 🥶"
            image = "cold"
        }
        else{
            result = "It is Hot 🥵"
            image = "hot"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //know the identifier
        let transition = segue.identifier
        //set the destination
        if(transition=="resultSegue") {
            let destination = segue.destination as! ResultViewController
            //Assign the values to the destination variables.
            destination.image=image
            destination.result=result
            destination.temperature=temp
        }
    }
    
}

