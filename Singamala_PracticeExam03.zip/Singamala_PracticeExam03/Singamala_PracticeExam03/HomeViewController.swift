//
//  ViewController.swift
//  Singamala_PracticeExam03
//
//  Created by Uday on 4/16/24.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create Cell
        var cell = TableViewOL.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
        let contact = contacts[indexPath.row]
        //populate
        cell.textLabel?.text = "\(contact.firstName) \(contact.lastName)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedContact = contacts[indexPath.row]
                performSegue(withIdentifier: "ContactSegue", sender: selectedContact)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ContactSegue",
           let destination = segue.destination as? profileViewController,
           let selectedContact = sender as? Contact {
            destination.contact = selectedContact
        }
    }


    @IBOutlet weak var TableViewOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TableViewOL.dataSource = self
        TableViewOL.delegate = self
    }
    


}

