//
//  ViewController.swift
//  Arigela_CalculatorApp
//
//  Created by Rajesh Arigela on 2/5/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonAllClear(_ sender: Any) {
        resultOutlet.text = ""
    }
    
    @IBAction func buttonClear(_ sender: Any) {
        resultOutlet.text = ""
    }
    
    @IBAction func buttonSignChange(_ sender: Any) {
        resultOutlet.text = ""
    }
    
    @IBAction func buttonDivide(_ sender: Any) {
        resultOutlet.text = "/"
    }
    
    @IBAction func buttonSeven(_ sender: Any) {
        resultOutlet.text = "7"
    }
    
    @IBAction func buttonEight(_ sender: Any) {
        resultOutlet.text = "8"
    }
    
    @IBAction func buttonNine(_ sender: Any) {
        resultOutlet.text = "9"
    }
    
    @IBAction func buttonMultiply(_ sender: Any) {
        resultOutlet.text = "*"
    }
    
    @IBAction func buttonFour(_ sender: Any) {
        resultOutlet.text = "4"
    }
    
    @IBAction func buttonFive(_ sender: Any) {
        resultOutlet.text = "5"
    }
    
    @IBAction func buttonSix(_ sender: Any) {
        resultOutlet.text = "6"
    }
    
    @IBAction func buttonMinus(_ sender: Any) {
        resultOutlet.text = "-"
    }
    
    @IBAction func buttonone(_ sender: Any) {
        resultOutlet.text = "1"
    }
    
    @IBAction func buttonTwo(_ sender: Any) {
        resultOutlet.text = "2"
    }
    
    @IBAction func buttonThree(_ sender: Any) {
        resultOutlet.text = "3"
    }

    @IBAction func buttonPlus(_ sender: Any) {
        resultOutlet.text = "+"
    }
    
    @IBAction func buttonZero(_ sender: Any) {
        resultOutlet.text = "0"
    }
    
    @IBAction func buttonDecimal(_ sender: Any) {
        resultOutlet.text = "."
    }
    
    @IBAction func buttonModular(_ sender: Any) {
        resultOutlet.text = "%"
    }
    
    @IBAction func buttonEquals(_ sender: Any) {
        resultOutlet.text = "="
    }

}
