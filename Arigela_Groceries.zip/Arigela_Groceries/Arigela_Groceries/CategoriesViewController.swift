//
//  ViewController.swift
//  Arigela_Groceries
//
//  Created by Arigela,Rajesh on 4/17/24.
//

import UIKit

class CategoriesViewController: UIViewController {
    
    
    @IBOutlet weak var categoryTableViewOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

