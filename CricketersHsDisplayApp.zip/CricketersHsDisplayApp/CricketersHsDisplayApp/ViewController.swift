//
//  ViewController.swift
//  CricketersHsDisplayApp
//
//  Created by Arigela,Rajesh on 2/26/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var teamOL: UILabel!
    
    @IBOutlet weak var opponentOL: UILabel!
    
    @IBOutlet weak var scoreOL: UILabel!
    
    @IBOutlet weak var previousOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    // Declare and initialize an array
    let cricketers = [["rohit","Rohit Sharma","India","Srilanka","264"],["guptil","Martin Guptill","New Zealand","West Indies","237"],["amelia","Amelia Kerr","New Zealand","Ireland","232"],["sehwag","Virender Sehwag","India","West Indies","219"]]
    
    var imgNo = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previous button should be disable on the home page
        previousOL.isEnabled=false;
        
        //Displaying first cricketer details on the home page
        updtCricketers(0)
        
    }

    @IBAction func prevButnClicked(_ sender: Any) {
        //next btn should be enabled.
        nextOL.isEnabled=true;
        
        //decrement the imgage io
        imgNo=imgNo-1
        
        //update the contents
        updtCricketers(imgNo)
        
        //once you reach the begining of the array, the prev btn should be disabled
        if(imgNo==0) {
            previousOL.isEnabled=false;
        }
    }
    
    
    @IBAction func nxtButnClicked(_ sender: Any) {
        //Prev btn should be enabled
        previousOL.isEnabled = true;
        
        //Increment the imgage no
        imgNo=imgNo+1
        
        //updating the cricketers details
        updtCricketers(imgNo)
        
        //once the user reach the end of the array, next btn should disabled
        if(imgNo==cricketers.count-1){
            nextOL.isEnabled=false;
        }
    }
    
    //Below is the helper function to update the cricketers info
    func updtCricketers(_ imageNum:Int) {
        imageOL.image=UIImage(named: cricketers[imageNum][0])
        nameOL.text=cricketers[imageNum][1]
        teamOL.text=cricketers[imageNum][2]
        opponentOL.text=cricketers[imageNum][3]
        scoreOL.text=cricketers[imageNum][4]
        
    }
    
}

